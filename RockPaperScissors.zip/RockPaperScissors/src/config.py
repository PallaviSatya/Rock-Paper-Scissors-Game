# src/config.py

MAX_ROUNDS = 5  # Set the maximum number of rounds to play
