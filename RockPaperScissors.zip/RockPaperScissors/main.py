# main.py

from src.gui import start_game

if __name__ == "__main__":
    start_game()
